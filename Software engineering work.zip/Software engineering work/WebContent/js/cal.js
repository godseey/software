 //简单日历插件
 var date=new Date();
		    week_day=date.getDay();
			mon_day=date.getDate();
			mon=1+date.getMonth();
			year=date.getFullYear();
			cn_week_day=new Array();
			cn_week_day[0]='日';
			cn_week_day[1]='一';
			cn_week_day[2]='二';
			cn_week_day[3]='三';
			cn_week_day[4]='四';
			cn_week_day[5]='五';
			cn_week_day[6]='六';
			
	          if(year%100==0 && year%400==0){
				 leap_or_comm='leap';
			  }
			    if(year%4==0){
				   leap_or_comm='leap';
				  }
			     if(year%100==0 && year%400!=0){
					 leap_or_comm='comm';
				 }
			       if(year%4!=0){
						   leap_or_comm='comm';
				    }
			  //闰年还是平年
document.write('<table style=\'text-align:center;\'>\
<caption>\
<span style=\'color:#8080FF\'>'+year+'</span>'+'年'+'<span style=\'color:#8080FF\'>'+mon+
'</span>'+'月'
 +'<span style=\'color:#8080FF\'>'+mon_day+'</span>'+'日<tr>'
 +'</caption>');
			  for(i=0;i<=6;i++){
				  document.write('<td>'+cn_week_day[i]+'</td>');
			  }
			       document.write('</tr><tr>');
			       for(i=0;i<week_day-(mon_day-1)%7;i++){
					   document.write('<td></td>');
				   }
				   d=1;
				   for(j=i;j<=6;j++){
					  if(d==mon_day){
						  document.write('<td style=\'color:red\'>'+d+'</td>');
					     }
					     else{
							   document.write('<td>'+d+'</td>');
						 }
					   d++;
				   }
				    for(j=1;j<=4;j++)
					{
				     document.write('</tr><tr>');
				     for(i=1;i<=7;i++){
						 if(d==mon_day){
						  document.write('<td style=\'color:red\'>'+d+'</td>');
					     }
					     else{
							   document.write('<td>'+d+'</td>');
						 }
					   d++;
							 if(leap_or_comm=='leap' && mon==2 && d>29){
							   break;
							      }
							    if(leap_or_comm=='comm' && mon==2 && d>28){
									break;
								}
								 if(mon%2==0 && mon!=2 && d>30){
								   break;
								  }
								   if(mon%2==1 && d>31){
									   break;
								   }
					 }
					}
				   document.write('</tr></table>');