package com.service;

import com.domain.Admin;

public interface AdminService {

	Boolean login(Admin a);


	
}
