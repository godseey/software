package com.service;

import java.util.List;
import java.util.Map;

import com.domain.Papern;

public interface PaperService {


	void save(Papern p);

	Map<String, Object> getAll(String pageNoStr);

	List<Papern> review();

	void pass(String id);

	void update(Papern p);

	void delete(String[] id);

	Map<String, Object> getdesc(String pageNoStr);

	Map<String, Object> getplist(String pageNoStr, String id);

	Map<String, Object> getndesc(String pageNoStr);

	Map<String, Object> getpdesc(String pageNoStr);

	Papern edita(String pid);

	void rcheck(String id);


	
}
