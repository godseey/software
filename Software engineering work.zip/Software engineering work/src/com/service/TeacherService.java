package com.service;

import java.util.List;
import java.util.Map;

import com.domain.Teacher;

public interface TeacherService {

	/*
	 * 从dao层接收 list<student>当前页学生信息列表
	 * pageUtil 分页信息
	 * 
	 * 如果返回的是多类型
	 * 习惯于使用map
	 * map.put("sList",sList)
	 * map.put("pu",pu)
	 * 返回map
	 */
	
	
	Map<String, Object> getAll(String pageNoStr);

	void add(Teacher t);

	Teacher edit(String id);

	void update(Teacher t);

	void delete(String[] id);

	String getuserid();

	void pass(String id);

	List<Teacher> listp();

	Boolean login(Teacher t);

	String getpassword(String tid);

	void pwd(Teacher t);

	void register(Teacher t);

	String check(Teacher t);

	boolean seach(String id);


	
	
	
}
