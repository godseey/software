package com.service.impl;

import com.dao.AdminDao;
import com.dao.TeacherDao;
import com.dao.impl.AdminDaoImpl;
import com.dao.impl.TeacherDaoImpl;
import com.domain.Admin;
import com.service.AdminService;

public class AdminServiceImpl implements AdminService {
	private AdminDao adminDao=new AdminDaoImpl();
	@Override
	public Boolean login(Admin a) {
		Boolean flag=adminDao.login(a);
		return flag;
	}
	
}
