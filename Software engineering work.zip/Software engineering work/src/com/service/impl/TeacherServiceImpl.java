package com.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dao.StudentDao;
import com.dao.TeacherDao;
import com.dao.impl.StudentDaoImpl;
import com.dao.impl.TeacherDaoImpl;
import com.domain.Student;
import com.domain.Teacher;
import com.service.TeacherService;
import com.sun.org.apache.bcel.internal.generic.NEW;
import com.util.PageUtil;

public class TeacherServiceImpl implements TeacherService {
	private TeacherDao teacherDao=new TeacherDaoImpl();

	

	@Override
	public void add(Teacher t) {
		teacherDao.add(t);
		
	}

	@Override
	public Teacher edit(String id) {
		Teacher t=teacherDao.edit(id);
		
		return t;
	}

	@Override
	public void update(Teacher t) {
		teacherDao.update(t);
		
	}

	@Override
	public void delete(String[] id) {
		teacherDao.delete(id);
		
	}

	@Override
	public String getuserid() {
		String id=teacherDao.getuserid();
		return id;
	}

	@Override
	public void pass(String id) {
		teacherDao.pass(id);
		
	}

	@Override
	public List<Teacher> listp() {
		List<Teacher> tList=teacherDao.listp();
		return tList;
	}

	@Override
	public Map<String, Object> getAll(String pageNoStr) {

		//取得当前页信息
		int pageNo=1;
		if(pageNoStr!=null && !"".equals(pageNoStr)){
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置一个每页显示多少条记录；
		
		int pageCount=8;
		
		//取一共有多少条记录
		int total=teacherDao.getTotal();
		
		//取一共有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		PageUtil pu=new PageUtil(); 
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		
		//下面取教师信息列表
		int skipCount =(pageNo-1)*pageCount;
		List<Teacher> tList=teacherDao.getAll(skipCount, pageCount);
		Map<String, Object> map=new HashMap<String,Object>();
		map.put("tList", tList);
		map.put("pu", pu);
		
		
		
		return map;
	}

	@Override
	public Boolean login(Teacher t) {
		Boolean flag=teacherDao.login(t);
		return flag;
	}

	@Override
	public String getpassword(String tid) {
		String password=teacherDao.getpassword(tid);
		return password;
	}

	@Override
	public void pwd(Teacher t) {
		teacherDao.pwd(t);
	}

	@Override
	public void register(Teacher t) {
		teacherDao.register(t);
		
	}

	@Override
	public String check(Teacher t) {
		String review=teacherDao.check(t);
		return review;
	}

	@Override
	public boolean seach(String id) {
		boolean flag=teacherDao.seach(id);
		return flag;
	}



}
