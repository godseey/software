package com.service.impl;

import java.awt.print.Paper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;

import com.dao.PaperDao;
import com.dao.impl.PaperDaoImpl;
import com.domain.Papern;
import com.service.PaperService;
import com.util.PageUtil;

public class PaperServiceImpl implements PaperService {
	private PaperDao paperDao=new PaperDaoImpl();
	@Override
	public void save(Papern p) {
		paperDao.save(p);
		System.out.println(p.getAuthor());
	}
	
	@Override
	public List<Papern> review() {
		List<Papern> pList=paperDao.review();
		return pList;
	}
	@Override
	public void pass(String id) {
		paperDao.pass(id);
		
	}
	@Override
	public void update(Papern p) {
		paperDao.update(p);
		
	}
	@Override
	public void delete(String[] id) {
		paperDao.delete(id);
		
	}

	@Override
	public Map<String, Object> getAll(String pageNoStr) {
		int pageNo=1;
		if (pageNoStr!=null && !"".equals(pageNoStr)) {
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置每页条数
		int pageCount=8;
		
		//获取总共多少条记录
		int total=paperDao.total();
		
		//取得有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		//所忽略条数
		int skipCount=(pageNo-1)*pageCount;
		
		//创建一个pageUtil类对象
		PageUtil pu=new PageUtil();
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		
		//调用dao层方法获取文章列表信息
		List<Papern> pList= paperDao.getall(skipCount,pageCount);
		
		//建立map对象
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("pu", pu);
		map.put("pList", pList);
		
		return map;
	}

	@Override
	public Map<String, Object> getdesc(String pageNoStr) {
		int pageNo=1;
		if (pageNoStr!=null && !"".equals(pageNoStr)) {
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置每页条数
		int pageCount=6;
		
		//获取总共多少条记录
		int total=paperDao.rtotal();
		
		//取得有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		//所忽略条数
		int skipCount=(pageNo-1)*pageCount;
		
		//创建一个pageUtil类对象
		PageUtil pu=new PageUtil();
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		List<Papern> pList=paperDao.getdesc(skipCount,pageCount);
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("pu", pu);
		map.put("pList", pList);
		
		return map;
	}

	@Override
	public Map<String, Object> getplist(String pageNoStr, String id) {
		int pageNo=1;
		if (pageNoStr!=null && !"".equals(pageNoStr)) {
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置每页条数
		int pageCount=8;
		
		//获取总共多少条记录
		int total=paperDao.plisttotal(id);
		
		//取得有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		//所忽略条数
		int skipCount=(pageNo-1)*pageCount;
		
		//创建一个pageUtil类对象
		PageUtil pu=new PageUtil();
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		
		//调用dao层方法获取文章列表信息
		List<Papern> pList= paperDao.getplist(skipCount,pageCount,id);
		
		//建立map对象
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("pu", pu);
		map.put("pList", pList);
		
		return map;
	}

	@Override
	public Map<String, Object> getndesc(String pageNoStr) {
		int pageNo=1;
		if (pageNoStr!=null && !"".equals(pageNoStr)) {
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置每页条数
		int pageCount=6;
		
		//获取总共多少条记录
		int total=paperDao.ntotal();
		
		//取得有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		//所忽略条数
		int skipCount=(pageNo-1)*pageCount;
		
		//创建一个pageUtil类对象
		PageUtil pu=new PageUtil();
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		List<Papern> nList=paperDao.getndesc(skipCount,pageCount);
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("pu", pu);
		map.put("nList", nList);
		
		return map;
	}

	@Override
	public Map<String, Object> getpdesc(String pageNoStr) {
		int pageNo=1;
		if (pageNoStr!=null && !"".equals(pageNoStr)) {
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置每页条数
		int pageCount=6;
		
		//获取总共多少条记录
		int total=paperDao.ptotal();
		
		//取得有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		//所忽略条数
		int skipCount=(pageNo-1)*pageCount;
		
		//创建一个pageUtil类对象
		PageUtil pu=new PageUtil();
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		List<Papern> pList=paperDao.getpdesc(skipCount,pageCount);
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("pu", pu);
		map.put("pList", pList);
		
		return map;
	}

	@Override
	public Papern edita(String pid) {
		Papern p=paperDao.edita(pid);
		return p;
	}

	@Override
	public void rcheck(String id) {
		paperDao.rcheck(id);
	}
	
}
