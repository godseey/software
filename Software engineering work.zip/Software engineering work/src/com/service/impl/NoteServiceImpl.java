package com.service.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dao.NoteDao;
import com.dao.impl.NoteDaoImpl;
import com.domain.Note;
import com.service.NoteService;
import com.util.PageUtil;

public class NoteServiceImpl implements NoteService {
	private NoteDao noteDao=new NoteDaoImpl();

	@Override
	public void add(Note n) {
		noteDao.add(n);
		
	}

	@Override
	public Map<String, Object> getAll(String pageNoStr) {
		int pageNo=1;
		if (pageNoStr!=null && !"".equals(pageNoStr)) {
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置每页条数
		int pageCount=6;
		
		//获取总共多少条记录
		int total=noteDao.total();
		
		//取得有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		//所忽略条数
		int skipCount=(pageNo-1)*pageCount;
		
		//创建一个pageUtil类对象
		PageUtil pu=new PageUtil();
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		
		//调用dao层方法获取文章列表信息
		List<Note> nList= noteDao.getall(skipCount,pageCount);
		
		//建立map对象
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("pu", pu);
		map.put("nList", nList);
		
		return map;
	}

	@Override
	public Map<String, Object> getrAll(String pageNoStr) {
		int pageNo=1;
		if (pageNoStr!=null && !"".equals(pageNoStr)) {
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置每页条数
		int pageCount=6;
		
		//获取总共多少条记录
		int total=noteDao.rtotal();
		
		//取得有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		//所忽略条数
		int skipCount=(pageNo-1)*pageCount;
		
		//创建一个pageUtil类对象
		PageUtil pu=new PageUtil();
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		
		//调用dao层方法获取文章列表信息
		List<Note> nList= noteDao.getrall(skipCount,pageCount);
		
		//建立map对象
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("pu", pu);
		map.put("nList", nList);
		
		return map;
	}

	@Override
	public void delete(String id) {
		noteDao.delete(id);
	}

	@Override
	public Note view(String id) {
		Note n=noteDao.view(id);
		return  n;
	}

	@Override
	public void pass(String id) {
		noteDao.pass(id);
		
	}

	@Override
	public void update(String tnote,String nid) {
		noteDao.update(tnote,nid);
		
	}
}
