package com.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dao.StudentDao;
import com.dao.impl.StudentDaoImpl;
import com.domain.Student;
import com.sun.org.apache.bcel.internal.generic.NEW;
import com.util.PageUtil;

public class StudentServiceImpl implements com.service.StudentService {
	private StudentDao studentDao=new StudentDaoImpl();

	

	@Override
	public void add(Student s) {
		studentDao.add(s);
		
	}

	@Override
	public Student edit(String id) {
		Student s=studentDao.edit(id);
		return s;
	}

	@Override
	public void update(Student s) {
	studentDao.update(s);
		
	}

	@Override
	public void delete(String[] id) {
	studentDao.delete(id);
		
	}

	@Override
	public String getuserid() {
		String id=studentDao.getuserid();
		return id;
	}

	@Override
	public void pass(String id) {
		studentDao.pass(id);
		
	}

	@Override
	public List<Student> listp() {
		List<Student>sList=studentDao.listp();
		return sList;
	}

	@Override
	public Map<String, Object> getAll(String pageNoStr) {
		//取得当前页信息
		int pageNo=1;
		if(pageNoStr!=null && !"".equals(pageNoStr)){
			pageNo=Integer.valueOf(pageNoStr);
		}
		//设置一个每页显示多少条记录；
		
		int pageCount=8;
		
		//取一共有多少条记录
		int total=studentDao.getTotal();
		
		//取一共有多少页
		int pageSize=total/pageCount;
		if(total%pageCount>0){
			pageSize++;
		}
		
		PageUtil pu=new PageUtil(); 
		pu.setPageCount(pageCount);
		pu.setPageNo(pageNo);
		pu.setPageSize(pageSize);
		pu.setTotal(total);
		
		
		//下面取学生信息列表
		int skipCount =(pageNo-1)*pageCount;
		List<Student> sList=studentDao.getAll(skipCount, pageCount);
		Map<String, Object> map=new HashMap<String,Object>();
		map.put("sList", sList);
		map.put("pu", pu);
		
		
		
		return map;
	}

	@Override
	public void register(Student s) {
		studentDao.register(s);
		
	}

	@Override
	public Boolean login(Student s) {
		Boolean flag=studentDao.login(s);
		return flag;
	}

	@Override
	public String getpassword(String id) {
		String password=studentDao.getpassword(id);
		return password;
	}

	@Override
	public void sc(String sid,String cid) {
		studentDao.sc(sid,cid);
		
	}

	@Override
	public List<Student> scl(String id) {
		List<Student> sList=studentDao.scl(id);
		return sList;
	}

	@Override
	public void dscl(String id,String cid) {
		studentDao.dscl(id,cid);
		
	}

	@Override
	public String check(Student s) {
		String review=studentDao.check(s);
		return review;
	}

	@Override
	public boolean seach(String id) {
		boolean flag=studentDao.seach(id);
		return flag;
	}



}
