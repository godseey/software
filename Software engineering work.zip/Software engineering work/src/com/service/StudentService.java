package com.service;

import java.util.List;
import java.util.Map;

import com.domain.Student;

public interface StudentService {

	/*
	 * 从dao层接收 list<student>当前页学生信息列表
	 * pageUtil 分页信息
	 * 
	 * 如果返回的是多类型
	 * 习惯于使用map
	 * map.put("sList",sList)
	 * map.put("pu",pu)
	 * 返回map
	 */
	
	
	Map<String, Object> getAll(String pageNoStr);

	void add(Student s);

	Student edit(String id);

	void update(Student s);

	void delete(String[] id);

	String getuserid();

	void pass(String id);

	List<Student> listp();

	void register(Student s);

	Boolean login(Student s);

	String getpassword(String id);

	void sc(String sid,String cid);

	List<Student> scl(String id);

	void dscl(String id, String cid);

	String check(Student s);

	boolean seach(String id);


	
	
	
}
