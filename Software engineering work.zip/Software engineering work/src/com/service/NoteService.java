package com.service;

import java.util.Map;

import com.domain.Note;

public interface NoteService {

	void add(Note n);

	Map<String, Object> getAll(String pageNoStr);

	Map<String, Object> getrAll(String pageNoStr);

	void delete(String id);

	Note view(String id);

	void pass(String id);

	void update(String tnote, String nid);

}
