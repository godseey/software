package com.domain;

public class Student {
	public Student(){}
	public Student(String id, String name, int age,String sex,String review,String password,String idc,String department,int ptype) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.review = review;
		this.password=password;
		this.idc=idc;
		this.department=department;
		this.ptype=ptype;
	}
	public String getIdc() {
		return idc;
	}
	public void setIdc(String idc) {
		this.idc = idc;
	}
	private String id;
	private String name;
	private String sex;
	private String review;
	private String password;
	private String idc;
	private String department;
	private int age;
	private int ptype;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public int getPtype() {
		return ptype;
	}
	public void setPtype(int ptype) {
		this.ptype = ptype;
	}
	
}
