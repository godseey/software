package com.domain;

public class Papern {
	public Papern(){}
	public Papern(String id,String title,String author,String content,String cif,String review,String desc,String teacher){
		this.cif=cif;
		this.id=id;
		this.title=title;
		this.author=author;
		this.content=content;
		this.review=review;
		this.desc=desc;
		this.teacher=teacher;
	}
	private String id;
	private String title;
	private String author;
	private String content;
	private String cif;
	private String review;
	private String desc;
	private String teacher;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	
}
