package com.domain;

public class Homework {
	public Homework(){}
	public Homework(int id,String course_id,String student_id,String content,String review,int grade,String course_name,String student_name){
		this.id=id;
		this.course_id=course_id;
		this.student_id=student_id;
		this.review=review;
		this.grade=grade;
		this.content=content;
		this.student_name=student_name;
		this.course_name=course_name;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	private int id;
	private String course_id;
	private String student_id;
	private String content;
	private String review;
	private int grade;
	private String course_name;
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	private String student_name;
}
