package com.domain;

public class Note {
	public Note(){}
	
	public Note(int id,String name,String content,String review,String tnote){
		this.id=id;
		this.name=name;
		this.content=content;
		this.setReview(review);
		this.setReview(tnote);
	}
	private int id;
	private String review;
	private String name;
	private String content;
	private String tnote;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getTnote() {
		return tnote;
	}

	public void setTnote(String tnote) {
		this.tnote = tnote;
	}
}
