package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dao.AdminDao;
import com.domain.Admin;
import com.util.DButil;

public class AdminDaoImpl implements AdminDao {

	@Override
	public Boolean login(Admin a) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		Boolean flag=true;
		String sql="select count(*) from tbl_admin where username=? and password=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, a.getId());
			ps.setString(2, a.getPassword());
			rs =ps.executeQuery();
			if (rs.next()) {
			count =rs.getInt(1);
			}

		} catch (SQLException  e) {
			e.printStackTrace();
			throw new RuntimeException();
		} 
		finally {

				DButil.myClose(null, ps, rs);
		}
		
		if(count!=1){
			flag=false;
		}
		
		return flag;
	}

	
}
