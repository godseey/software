package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dao.NoteDao;
import com.domain.Note;
import com.util.DButil;
import com.util.UUIDUtil;

public class NoteDaoImpl implements NoteDao {

	@Override
	public void add(Note n) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="insert into tbl_note(name,content,tnote) values(?,?,?)";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, n.getName());
			ps.setString(2, n.getContent());
			ps.setString(3, n.getTnote());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
	}

	@Override
	public int total() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_note where review=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "YES");
			rs=ps.executeQuery();
			if (rs.next()){
				count=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return count;
	}

	@Override
	public List<Note> getall(int skipCount, int pageCount) {
		System.out.println("进入dao层");
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="SELECT `name`,content,review,id FROM tbl_note WHERE review=? limit ?,?";
		List<Note> nList=new ArrayList<Note>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "yes");
			ps.setInt(2, skipCount);
			ps.setInt(3, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Note n=new Note();
				n.setName(rs.getString(1));
				n.setContent(rs.getString(2));
				n.setReview(rs.getString(3));
				n.setId(rs.getInt(4));
				nList.add(n);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return nList;
	}

	@Override
	public int rtotal() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_note";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			if (rs.next()){
				count=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return count;
	}

	@Override
	public List<Note> getrall(int skipCount, int pageCount) {
		System.out.println("进入dao层");
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="SELECT `name`,content,review,id FROM tbl_note limit ?,?";
		List<Note> nList=new ArrayList<Note>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setInt(1, skipCount);
			ps.setInt(2, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Note n=new Note();
				n.setName(rs.getString(1));
				n.setContent(rs.getString(2));
				n.setReview(rs.getString(3));
				n.setId(rs.getInt(4));
				nList.add(n);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return nList;
	}

	@Override
	public void delete(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="delete from tbl_note where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public Note view(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Note n=new Note();
		String sql="select name,review,content,tnote from tbl_note where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if (rs.next()){
			n.setName(rs.getString(1));
			n.setReview(rs.getString(2));
			n.setContent(rs.getString(3));
			n.setTnote(rs.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return n;
	}

	@Override
	public void pass(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String review="YES";
		String sql="update tbl_note set review=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, review);
			ps.setString(2, id);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
	}

	@Override
	public void update(String tnote, String nid) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="update tbl_note set tnote=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, tnote);
			ps.setString(2, nid);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
	}

}
