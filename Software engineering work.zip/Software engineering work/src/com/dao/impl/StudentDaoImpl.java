package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.Response;

import com.dao.StudentDao;
import com.domain.Student;
import com.sun.xml.internal.bind.v2.model.core.ID;
import com.util.DButil;
import com.util.UUIDUtil;

import sun.security.krb5.internal.crypto.RsaMd5DesCksumType;

public class StudentDaoImpl implements StudentDao {

	@Override
	public List<Student> getAll(int skipCount,int pageCount) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id,name,age,review from tbl_student limit ?,?";
		List<Student> sList=new ArrayList<Student>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setInt(1, skipCount);
			ps.setInt(2, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Student s=new Student();
				s.setId(rs.getString(1));
				s.setName(rs.getString(2));
				s.setAge(rs.getInt(3));
				s.setReview(rs.getString(4));
				sList.add(s);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return sList;
	}

	@Override
	public void add(Student s) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="insert into tbl_student(id,name,age) values(?,?,?)";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, UUIDUtil.getUUID());
			ps.setString(2, s.getName());
			ps.setInt(3, s.getAge());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
	}

	@Override
	public Student edit(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Student s=new Student();
		String sql="select `name`,age,`password`,sex,department,idc,ptype from tbl_student where id=?";
		try {
			conn=DButil.getConn();

			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if (rs.next()){
				s.setId(id);
				s.setName(rs.getString(1));
				s.setAge(rs.getInt(2));
				s.setPassword(rs.getString(3));
				s.setSex(rs.getString(4));
				s.setDepartment(rs.getString(5));
				s.setIdc(rs.getString(6));
				s.setPtype(rs.getInt(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return s;
	}

	@Override
	public void update(Student s) {
		Connection conn=null;
		PreparedStatement ps=null;
		int ptype=1;
		String sql="update tbl_student set name=?,age=?,sex=?,department=?,idc=?,ptype=? where id=?";
		String sql1="update tbl_student set password=? where id=?";
		try {
			conn=DButil.getConn();
			if(s.getPassword()==null){
				ps=conn.prepareStatement(sql);
				ps.setString(1, s.getName());
				ps.setInt(2, s.getAge());
				ps.setString(3, s.getSex());
				ps.setString(4, s.getDepartment());
				ps.setString(5, s.getIdc());
				ps.setInt(6, ptype);
				ps.setString(7, s.getId());
				ps.executeUpdate();
			}else{
				ps=conn.prepareStatement(sql1);
				ps.setString(1, s.getPassword());
				ps.setString(2, s.getId());
				ps.executeUpdate();
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
		
	}

	@Override
	public void delete(String[] id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="delete from tbl_student where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			for (String id1:id) {
				ps.setString(1, id1);
				ps.executeUpdate();
			}
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		
	}

	@Override
	public String getuserid() {
		String id=UUIDUtil.getUUID();
		
		return id;
	}

	@Override
	public void pass(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String review="YES";
		String sql="update tbl_student set review=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, review);
			ps.setString(2, id);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
		
	}

	@Override
	public List<Student> listp() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String review="NO";
		String sql="select id,name,age,review from tbl_student where review=?";
		List<Student> sList=new ArrayList<Student>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, review);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Student s=new Student();
				s.setId(rs.getString(1));
				s.setName(rs.getString(2));
				s.setAge(rs.getInt(3));
				s.setReview(rs.getString(4));
				sList.add(s);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return sList;
	}

	@Override
	public int getTotal() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_student";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			
			if (rs.next()){
				count=rs.getInt(1);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return count;
	}

	@Override
	public void register(Student s) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="insert into tbl_student(id,name,password,idc) values(?,?,?,?)";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1,s.getId());
			ps.setString(2, s.getName());
			ps.setString(3, s.getPassword());
			ps.setString(4, s.getIdc());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
	}

	@Override
	public Boolean login(Student s) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		Boolean flag=true;
		String sql="select count(*) from tbl_student where id=? and password=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, s.getId());
			ps.setString(2, s.getPassword());
			rs =ps.executeQuery();
			if (rs.next()) {
			count =rs.getInt(1);
			}

		} catch (SQLException  e) {
			e.printStackTrace();
			throw new RuntimeException();
		} 
		finally {

				DButil.myClose(null, ps, rs);

		}
		
		if(count!=1){
			flag=false;
		}
		
		return flag;
	}

	@Override
	public String getpassword(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String password=null;
		String sql="select password from tbl_student where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if (rs.next()) {
				password=rs.getString(1);
				}
			System.out.println(password);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return password;
	}

	@Override
	public void sc(String sid,String cid) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="insert into tbl_sc(student_id,course_id) values(?,?)";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, sid);
			ps.setString(2, cid);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
	}

	@Override
	public List<Student> scl(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="SELECT tbl_student.id,tbl_student.`name`,tbl_student.age,tbl_student.department,tbl_student.sex FROM tbl_student JOIN tbl_sc ON tbl_student.id=tbl_sc.student_id WHERE tbl_sc.course_id=?";
		List<Student> sList=new ArrayList<Student>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Student s=new Student();
				s.setId(rs.getString(1));
				s.setName(rs.getString(2));
				s.setAge(rs.getInt(3));
				s.setDepartment(rs.getString(4));
				s.setSex(rs.getString(5));
				sList.add(s);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return sList;
	}

	@Override
	public void dscl(String id,String cid) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="delete from tbl_sc where student_id=? AND course_id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, cid);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		
	}

	@Override
	public String check(Student s) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String review="NO";
		String sql="select review from tbl_student where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, s.getId());
			rs=ps.executeQuery();
			if (rs.next()) {
				review=rs.getString(1);
				}
			System.out.println(review);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return review;
	}

	@Override
	public boolean seach(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		Boolean flag=true;
		String sql="select count(*) from tbl_student where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs =ps.executeQuery();
			if (rs.next()) {
			count =rs.getInt(1);
			}

		} catch (SQLException  e) {
			e.printStackTrace();
			throw new RuntimeException();
		} 
		finally {

				DButil.myClose(null, ps, rs);

		}
		
		if(count!=0){
			flag=false;
		}
		
		return flag;
	}
	
}
