package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dao.PaperDao;
import com.domain.Papern;
import com.domain.Student;
import com.util.DButil;
import com.util.UUIDUtil;

public class PaperDaoImpl implements PaperDao {

	@Override
	public void save(Papern p) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="insert into tbl_paper(title,author,content,cif,descp,teacher_id) values(?,?,?,?,?,?)";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, p.getTitle());
			ps.setString(2, p.getAuthor());
			ps.setString(3, p.getContent());
			ps.setString(4, p.getCif());
			ps.setString(5, p.getDesc());
			ps.setString(6, p.getTeacher());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
	}

	@Override
	public List<Papern> getall(int skipCount, int pageCount) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id,title,author,cif,review from tbl_paper limit ?,?";
		List<Papern> pList=new ArrayList<Papern>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setInt(1, skipCount);
			ps.setInt(2, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Papern p=new Papern();
				p.setId(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setAuthor(rs.getString(3));
				p.setCif(rs.getString(4));
				p.setReview(rs.getString(5));
				pList.add(p);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return pList;
	}


	@Override
	public List<Papern> review() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String review="no";
		String sql="select id,title,author,cif,review from tbl_paper where review=?";
		List<Papern> pList=new ArrayList<Papern>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, review);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Papern p=new Papern();
				p.setId(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setAuthor(rs.getString(3));
				p.setCif(rs.getString(4));
				p.setReview(rs.getString(5));
				pList.add(p);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return pList;
	}

	@Override
	public void pass(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String review="YES";
		String sql="update tbl_paper set review=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, review);
			ps.setString(2, id);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
		
	}

	@Override
	public void update(Papern p) {
		Connection conn=null;
		PreparedStatement ps=null;
		System.out.println(p.getContent());
		String sql="update tbl_paper set title=?,author=?,cif=?,content=?,descp=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, p.getTitle());
			ps.setString(2, p.getAuthor());
			ps.setString(3, p.getCif());
			ps.setString(4, p.getContent());
			ps.setString(5, p.getDesc());
			ps.setString(6, p.getId());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
		
	}

	@Override
	public void delete(String[] id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="delete from tbl_paper where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			for (String id1:id) {
				ps.setString(1, id1);
				ps.executeUpdate();
			}
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		
	}

	@Override
	public int total() {
		//统计有多少条记录
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_paper";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			if (rs.next()){
				count=rs.getInt(1);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return count;
		
	}

	@Override
	public List<Papern> getdesc(int skipCount, int pageCount) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id,title,author,cif,descp from tbl_paper where review=? limit ?,?";
		List<Papern> pList=new ArrayList<Papern>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "yes");
			ps.setInt(2, skipCount);
			ps.setInt(3, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Papern p=new Papern();
				p.setId(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setAuthor(rs.getString(3));
				p.setCif(rs.getString(4));		
				p.setDesc(rs.getString(5));
				pList.add(p);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return pList;
	}

	@Override
	public int plisttotal(String id) {
		//根据教师id统计有多少条文章记录
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_paper where teacher_id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if (rs.next()){
				count=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return count;
	}

	@Override
	public List<Papern> getplist(int skipCount, int pageCount, String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		System.out.println("dao："+id);
		String sql="select tbl_paper.id,tbl_paper.title,tbl_paper.review,tbl_teacher.`name` from tbl_paper JOIN tbl_teacher ON tbl_teacher.id=tbl_paper.teacher_id WHERE tbl_paper.teacher_id=? limit ?,?";
		List<Papern> pList=new ArrayList<Papern>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setInt(2, skipCount);
			ps.setInt(3, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Papern p=new Papern();
				p.setId(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setReview(rs.getString(3));
				p.setTeacher(rs.getString(4));
				pList.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return pList;
	}

	@Override
	public int rtotal() {
		//统计有多少审核通过的文章
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_paper where review=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "yes");
			rs=ps.executeQuery();
			if (rs.next()){
				count=rs.getInt(1);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return count;
	}

	@Override
	public int ntotal() {
		//统计有多少审核通过的时政新闻
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_paper where review=? AND cif=? ";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "yes");
			ps.setString(2, "时政新闻");
			rs=ps.executeQuery();
			if (rs.next()){
				count=rs.getInt(1);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return count;
	}

	@Override
	public List<Papern> getndesc(int skipCount, int pageCount) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id,title,author,cif,descp from tbl_paper where review=? AND cif=? limit ?,?";
		List<Papern> nList=new ArrayList<Papern>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "yes");
			ps.setString(2, "时政新闻");
			ps.setInt(3, skipCount);
			ps.setInt(4, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Papern n=new Papern();
				n.setId(rs.getString(1));
				n.setTitle(rs.getString(2));
				n.setAuthor(rs.getString(3));
				n.setCif(rs.getString(4));
				n.setDesc(rs.getString(5));
				nList.add(n);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return nList;
	}

	@Override
	public int ptotal() {
		//统计有多少审核通过的时政新闻
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_paper where review=? AND cif=? ";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "yes");
			ps.setString(2, "国防文章");
			rs=ps.executeQuery();
			if (rs.next()){
				count=rs.getInt(1);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return count;
	}

	@Override
	public List<Papern> getpdesc(int skipCount, int pageCount) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id,title,author,cif,descp from tbl_paper where review=? limit ?,?";
		List<Papern> pList=new ArrayList<Papern>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "yes");
			ps.setInt(2, skipCount);
			ps.setInt(3, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Papern p=new Papern();
				p.setId(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setAuthor(rs.getString(3));
				p.setCif(rs.getString(4));
				p.setDesc(rs.getString(5));
				pList.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return pList;
	}

	@Override
	public Papern edita(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Papern p=new Papern();
		String sql="select cif,title,author,content,descp from tbl_paper where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if (rs.next()){
				p.setCif(rs.getString(1));
				p.setTitle(rs.getString(2));
				p.setAuthor(rs.getString(3));
				p.setContent(rs.getString(4));
				p.setDesc(rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return p;
	}

	@Override
	public void rcheck(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="update tbl_paper set review=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, "NO");
			ps.setString(2, id);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
	}
	
}
