package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.Response;

import com.dao.StudentDao;
import com.dao.TeacherDao;
import com.domain.Student;
import com.domain.Teacher;
import com.sun.xml.internal.bind.v2.model.core.ID;
import com.util.DButil;
import com.util.UUIDUtil;

import sun.security.krb5.internal.crypto.RsaMd5DesCksumType;

public class TeacherDaoImpl implements TeacherDao {

	@Override
	public List<Teacher> getAll(int skipCount,int pageCount) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id,name,age,review,department from tbl_teacher limit ?,?";
		List<Teacher> tList=new ArrayList<Teacher>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setInt(1, skipCount);
			ps.setInt(2, pageCount);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Teacher t=new Teacher();
				t.setId(rs.getString(1));
				t.setName(rs.getString(2));
				t.setAge(rs.getInt(3));
				t.setReview(rs.getString(4));
				t.setDepartment(rs.getString(5));
				tList.add(t);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return tList;
	}

	@Override
	public void add(Teacher t) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="insert into tbl_teacher(id,name,age,department) values(?,?,?,?)";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, UUIDUtil.getTUUID());
			ps.setString(2, t.getName());
			ps.setInt(3, t.getAge());
			ps.setString(4, t.getDepartment());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
	}

	@Override
	public Teacher edit(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Teacher t=new Teacher();
		String sql="select name,age,department from tbl_teacher where id=?";
		try {
			conn=DButil.getConn();

			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if (rs.next()){
				t.setId(id);
				t.setName(rs.getString(1));
				t.setAge(rs.getInt(2));
				t.setDepartment(rs.getString(3));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return t;
	}

	@Override
	public void update(Teacher t) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="update tbl_teacher set name=?,age=?,department=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, t.getName());
			ps.setInt(2, t.getAge());
			ps.setString(3, t.getDepartment());
			ps.setString(4, t.getId());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
		
	}

	@Override
	public void delete(String[] id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="delete from tbl_teacher where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			for (String id1:id) {
				ps.setString(1, id1);
				ps.executeUpdate();
			}
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		
	}

	@Override
	public String getuserid() {
		String id=UUIDUtil.getTUUID();
		
		return id;
	}

	@Override
	public void pass(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		String review="YES";
		String sql="update tbl_teacher set review=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, review);
			ps.setString(2, id);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
		
	}

	@Override
	public List<Teacher> listp() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String review="NO";
		String sql="select id,name,age,review,department from tbl_teacher where review=?";
		List<Teacher> tList=new ArrayList<Teacher>();
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, review);
			rs=ps.executeQuery();
			//while循环几次 就创建几次对象，就会输出几次
			while(rs.next()){
				Teacher t=new Teacher();
				t.setId(rs.getString(1));
				t.setName(rs.getString(2));
				t.setAge(rs.getInt(3));
				t.setDepartment(rs.getString(4));
				t.setReview(rs.getString(5));
				tList.add(t);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		return tList;
	}

	@Override
	public int getTotal() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		String sql="select count(*) from tbl_teacher";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			
			if (rs.next()){
				count=rs.getInt(1);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return count;
	}

	@Override
	public Boolean login(Teacher t) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		Boolean flag=true;
		String sql="select count(*) from tbl_teacher where id=? and password=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, t.getId());
			ps.setString(2, t.getPassword());
			rs =ps.executeQuery();
			if (rs.next()) {
			count =rs.getInt(1);
			}

		} catch (SQLException  e) {
			e.printStackTrace();
			throw new RuntimeException();
		} 
		finally {

				DButil.myClose(null, ps, rs);

		}
		
		if(count!=1){
			flag=false;
		}
		
		return flag;
	}

	@Override
	public String getpassword(String tid) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String password=null;
		String sql="select password from tbl_teacher where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, tid);
			rs=ps.executeQuery();
			if (rs.next()) {
				password=rs.getString(1);
				}
			System.out.println(password);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return password;
	}

	@Override
	public void pwd(Teacher t) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="update tbl_teacher set password=? where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, t.getPassword());
			ps.setString(2, t.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
		
	}

	@Override
	public void register(Teacher t) {
		Connection conn=null;
		PreparedStatement ps=null;
		String sql="insert into tbl_teacher(id,name,password,idc) values(?,?,?,?)";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, t.getId());
			ps.setString(2, t.getName());
			ps.setString(3, t.getPassword());
			ps.setString(4, t.getIdc());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, null);
		}
	}

	@Override
	public String check(Teacher t) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String review="NO";
		String sql="select review from tbl_teacher where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, t.getId());
			rs=ps.executeQuery();
			if (rs.next()) {
				review=rs.getString(1);
				}
			System.out.println(review);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}finally {
			DButil.myClose(null, ps, rs);
		}
		
		return review;
	}

	@Override
	public boolean seach(String id) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int count=0;
		Boolean flag=true;
		String sql="select count(*) from tbl_teacher where id=?";
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs =ps.executeQuery();
			if (rs.next()) {
			count =rs.getInt(1);
			}

		} catch (SQLException  e) {
			e.printStackTrace();
			throw new RuntimeException();
		} 
		finally {

				DButil.myClose(null, ps, rs);

		}
		
		if(count!=0){
			flag=false;
		}
		
		return flag;
	}



}
