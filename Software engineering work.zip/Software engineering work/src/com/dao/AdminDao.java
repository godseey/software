package com.dao;

import com.domain.Admin;

public interface AdminDao {


	Boolean login(Admin a);
	
}
