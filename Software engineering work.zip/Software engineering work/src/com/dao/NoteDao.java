package com.dao;

import java.util.List;

import com.domain.Note;

public interface NoteDao {

	void add(Note n);

	int total();

	List<Note> getall(int skipCount, int pageCount);

	int rtotal();

	List<Note> getrall(int skipCount, int pageCount);

	void delete(String id);

	Note view(String id);

	void pass(String id);

	void update(String tnote, String nid);

}
