package com.dao;

import java.util.List;

import com.domain.Student;
import com.domain.Teacher;

public interface TeacherDao {

	List<Teacher> getAll(int skipCount,int pageCount);

	void add(Teacher s);

	Teacher edit(String id);

	void update(Teacher t);

	void delete(String[] id);

	String getuserid();

	void pass(String id);

	List<Teacher> listp();

	int getTotal();

	Boolean login(Teacher t);

	String getpassword(String tid);

	void pwd(Teacher t);

	void register(Teacher t);

	String check(Teacher t);

	boolean seach(String id);

	

}
