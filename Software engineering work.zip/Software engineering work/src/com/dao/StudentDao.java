package com.dao;

import java.util.List;

import com.domain.Student;

public interface StudentDao {

	List<Student> getAll(int skipCount,int pageCount);

	void add(Student s);

	Student edit(String id);

	void update(Student s);

	void delete(String[] id);

	String getuserid();

	void pass(String id);

	List<Student> listp();

	int getTotal();

	void register(Student s);

	Boolean login(Student s);

	String getpassword(String id);

	void sc(String sid,String cid);

	List<Student> scl(String id);

	void dscl(String id, String cid);

	String check(Student s);

	boolean seach(String id);
	

}
