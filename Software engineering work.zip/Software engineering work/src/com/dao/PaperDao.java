package com.dao;

import java.util.List;

import com.domain.Papern;

public interface PaperDao {

	void save(Papern p);

	List<Papern> getall(int skipCount, int pageCount);

	List<Papern> review();

	void pass(String id);

	void update(Papern p);

	void delete(String[] id);

	int total();

	List<Papern> getdesc(int skipCount, int pageCount);

	int plisttotal(String id);

	List<Papern> getplist(int skipCount, int pageCount, String id);

	int rtotal();

	int ntotal();

	List<Papern> getndesc(int skipCount, int pageCount);

	int ptotal();

	List<Papern> getpdesc(int skipCount, int pageCount);

	Papern edita(String id);

	void rcheck(String id);


}
