package com.util;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;

import javax.print.PrintException;

public class TranscationInvocationHandler implements InvocationHandler {
	private Object target;
	public TranscationInvocationHandler(Object target){
		this.target=target;
	}
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		Connection conn=null;
		Object obj=null;
		try {
			conn=DButil.getConn();
			conn.setAutoCommit(false);
			
		obj = method.invoke(target, args);
			
			
			
			conn.commit();
		} catch (Exception e) {
			conn.rollback();
			e.printStackTrace();
		}finally {
			DButil.myClose(conn, null, null);
		}
		return obj;
	}
	public Object getProxy(){
		return Proxy.newProxyInstance(target.getClass().getClassLoader(), target.getClass().getInterfaces(), this);
	}

}
