package com.util;

import com.sun.org.apache.bcel.internal.generic.NEW;

public class ServiceFactory {
	public static Object getService(Object  service){
		return new TranscationInvocationHandler(service).getProxy();
	}
}
