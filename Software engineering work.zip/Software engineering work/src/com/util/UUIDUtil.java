package com.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class UUIDUtil {
	
	public static String getUUID() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id from tbl_student order by id DESC limit 1";
		String id=null;	
	
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			rs =ps.executeQuery();
			if (rs.next()) {
				id=rs.getString(1);
			}
		} catch (SQLException  e) {
			e.printStackTrace();
			throw new RuntimeException();
		} finally {

				DButil.myClose(null, ps, rs);

		}
		String[] strs = id.split("[^0-9]");//根据不是数字的字符拆分字符串
	    String numStr = strs[strs.length-1];//取出最后一组数字
	    if(numStr != null && numStr.length()>0){//如果最后一组没有数字(也就是不以数字结尾)，抛NumberFormatException异常
	        int n = numStr.length();//取出字符串的长度
	        int num = Integer.parseInt(numStr)+1;//将该数字加一
	        String added = String.valueOf(num);
	        n = Math.min(n, added.length());
	        //拼接字符串
	        id=id.subSequence(0, id.length()-n)+added;
	    }else{
	        throw new NumberFormatException();
	    }
	    return id;
	}
	
	public static String getTUUID() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id from tbl_teacher order by id DESC limit 1";
		String id=null;	
	
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			rs =ps.executeQuery();
			if (rs.next()) {
				id=rs.getString(1);
			}
		} catch (SQLException  e) {
			e.printStackTrace();
			throw new RuntimeException();
		} finally {

				DButil.myClose(null, ps, rs);

		}
		String[] strs = id.split("[^0-9]");//根据不是数字的字符拆分字符串
	    String numStr = strs[strs.length-1];//取出最后一组数字
	    if(numStr != null && numStr.length()>0){//如果最后一组没有数字(也就是不以数字结尾)，抛NumberFormatException异常
	        int n = numStr.length();//取出字符串的长度
	        int num = Integer.parseInt(numStr)+1;//将该数字加一
	        String added = String.valueOf(num);
	        n = Math.min(n, added.length());
	        //拼接字符串
	        id=id.subSequence(0, id.length()-n)+added;
	    }else{
	        throw new NumberFormatException();
	    }
	    return id;
	}
	
	
	public static String getCUUID() {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String sql="select id from tbl_course order by id DESC limit 1";
		String id=null;	
	
		try {
			conn=DButil.getConn();
			ps=conn.prepareStatement(sql);
			rs =ps.executeQuery();
			if (rs.next()) {
				id=rs.getString(1);
			}
		} catch (SQLException  e) {
			e.printStackTrace();
			throw new RuntimeException();
		} finally {

				DButil.myClose(null, ps, rs);

		}
		String[] strs = id.split("[^0-9]");//根据不是数字的字符拆分字符串
	    String numStr = strs[strs.length-1];//取出最后一组数字
	    if(numStr != null && numStr.length()>0){//如果最后一组没有数字(也就是不以数字结尾)，抛NumberFormatException异常
	        int n = numStr.length();//取出字符串的长度
	        int num = Integer.parseInt(numStr)+1;//将该数字加一
	        String added = String.valueOf(num);
	        n = Math.min(n, added.length());
	        //拼接字符串
	        id=id.subSequence(0, id.length()-n)+added;
	    }else{
	        throw new NumberFormatException();
	    }
	    return id;
	}
}
