package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;

public class DButil {
	private DButil () {
	}
	private static Properties prop = new Properties();
	private static DruidDataSource dds = null;
	static{
		try {
			//db_server.properties
			prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream ("db_server.properties"));
			dds = (DruidDataSource) DruidDataSourceFactory.createDataSource(prop);
			}catch (Exception e) {
				e.printStackTrace();
			}
	}

	private static ThreadLocal<Connection> t=new ThreadLocal<Connection>();
	//取得连接
	public static Connection getConn() throws SQLException{
		
		Connection conn=t.get();
		if(conn==null){
			conn=dds.getConnection();
			t.set(conn);
		}
		
		return conn;
	}
	//关闭相关资源
	public static void myClose(Connection conn,PreparedStatement ps,ResultSet rs) {
		//关闭的顺序是按照创建出来的书序 逆序关闭
		if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		if(ps!=null){
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		}
		if(conn!=null){
			
				try {
					conn.close();
					t.remove();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
	}
}
