package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.domain.Admin;
import com.domain.Student;
import com.domain.Teacher;
import com.service.AdminService;
import com.service.StudentService;
import com.service.TeacherService;
import com.service.impl.AdminServiceImpl;
import com.service.impl.StudentServiceImpl;
import com.service.impl.TeacherServiceImpl;
import com.sun.org.apache.xalan.internal.xsltc.cmdline.getopt.GetOpt;
import com.util.ServiceFactory;

public class SignController  extends HttpServlet  {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("进入登录操作");
		String servletPath  = request.getServletPath();
		StudentService studentService=(StudentService) ServiceFactory.getService(new StudentServiceImpl());
		TeacherService teacherService=(TeacherService) ServiceFactory.getService(new TeacherServiceImpl());
		AdminService adminService=(AdminService) ServiceFactory.getService(new AdminServiceImpl());
		if (servletPath.equals("/student/login.do")) {
					
			sign(request,response,studentService);
					
		}else if(servletPath.equals("/teacher/login.do")) {
			
			sign(request,response,teacherService);
					
		} else if(servletPath.equals("/manager/login.do")) {
			
			sign(request,response,adminService);
					
		} 
	}
	
	private void sign(HttpServletRequest request, HttpServletResponse response, AdminService adminService)throws ServletException, IOException{
		System.out.println("进入管理员登录操作");
		String id = request.getParameter("u");
		String pwd = request.getParameter("p");
		Admin a=new Admin();
		a.setId(id);
		a.setPassword(pwd);
		Boolean flag=adminService.login(a); 
		if(flag){
			request.getSession().setAttribute("admin", id);
			response.sendRedirect(request.getContextPath()+"/index.jsp");
		}else{
			PrintWriter out = response.getWriter();
			out.print("<script>alert('密码错误，请重新输入');history.go(-1);</script>");
			out.close();
			/*response.sendRedirect(request.getContextPath()+"/login/admin.html");*/
		}
		
	}

	private void sign(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService) throws ServletException, IOException{
		System.out.println("进入教师登录操作");
		String id = request.getParameter("u");
		String pwd = request.getParameter("p");
		Teacher t=new Teacher();
		t.setId(id);
		t.setPassword(pwd);
		String review=teacherService.check(t);
		if(review.equals("NO")){
			response.sendRedirect(request.getContextPath()+"/remindr.html");
		}else{
			Boolean flag=teacherService.login(t); 
			if(flag){
				request.getSession().setAttribute("teacher", id);
				response.sendRedirect(request.getContextPath()+"/index.jsp");
			}else{
				PrintWriter out = response.getWriter();
				out.print("<script>alert('密码错误，请重新输入');history.go(-1);</script>");
				out.close();
				/*response.sendRedirect(request.getContextPath()+"/login/teacher.html");*/
			}
		}
		
		
	}

	private void sign(HttpServletRequest request, HttpServletResponse response, StudentService studentService) throws ServletException, IOException{
		System.out.println("进入学生登录操作");
		String id = request.getParameter("u");
		String pwd = request.getParameter("p");
		Student s=new Student();
		s.setId(id);
		s.setPassword(pwd);
		String review=studentService.check(s);
		if(review.equals("NO")){
			response.sendRedirect(request.getContextPath()+"/remindr.html");
		}else{
			Boolean flag=studentService.login(s); 
			if(flag){
				request.getSession().setAttribute("student", id);
				response.sendRedirect(request.getContextPath()+"/index.jsp");
			}else{
				PrintWriter out = response.getWriter();
				out.print("<script>alert('密码错误，请重新输入');history.go(-1);</script>");
				out.close();
				/*response.sendRedirect(request.getContextPath()+"/login/student.html");*/
			}
		}
		
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doGet(request, response);
	}
}
