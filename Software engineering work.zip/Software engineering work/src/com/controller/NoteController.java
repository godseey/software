package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.NoteDao;
import com.domain.Note;
import com.service.NoteService;
import com.service.impl.NoteServiceImpl;
import com.util.PageUtil;
import com.util.ServiceFactory;

/**
 * Servlet implementation class NoteController
 */
public class NoteController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		NoteService noteService=(NoteService) ServiceFactory.getService(new NoteServiceImpl());
		System.out.println("留言操作模块");
		String servletPath  = request.getServletPath();
		if (servletPath.equals("/note/add.do")) {
			
			add(request,response,noteService);
					
		}else if(servletPath.equals("/note/delete.do")) {
			
			delete(request,response,noteService);
			
		}else if(servletPath.equals("/note/pass.do")) {
			
			pass(request,response,noteService);
			
		}else if(servletPath.equals("/note/list.do")) {
			
			list(request,response,noteService);
			
		}else if(servletPath.equals("/note/alist.do")) {
			
			alist(request,response,noteService);
			
		}else if(servletPath.equals("/note/view.do")) {
			
			view(request,response,noteService);
			
		}else if(servletPath.equals("/note/update.do")) {
			
			update(request,response,noteService);
			
		} 
		
	}

	private void update(HttpServletRequest request, HttpServletResponse response, NoteService noteService)throws ServletException, IOException {
		System.out.println("进入通过添加留言操作");
		String tnote = request.getParameter("content");
		String nid = request.getParameter("nid");
		noteService.update(tnote,nid);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('回复成功');history.go(-1);</script>");
		out.close();
		
	}

	private void pass(HttpServletRequest request, HttpServletResponse response, NoteService noteService)throws ServletException, IOException {
		System.out.println("进入通过指定留言操作");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String id= request.getParameter("id");
		noteService.pass(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('留言审核成功');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/note/index.jsp");*/
	}

	private void view(HttpServletRequest request, HttpServletResponse response, NoteService noteService)throws ServletException, IOException {
		System.out.println("进入显示指定留言具体内容操作");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String id= request.getParameter("id");
		Note n=noteService.view(id);
		StringBuffer buf=new StringBuffer();
		buf.append("{\"name\":\""+n.getName()+"\",\"content\":\""+n.getContent()+"\",\"review\":\""+n.getReview()+"\",\"tnote\":\""+n.getTnote()+"\"}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
		
	}

	private void delete(HttpServletRequest request, HttpServletResponse response, NoteService noteService)throws ServletException, IOException {
		System.out.println("进入删除指定留言操作");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String id= request.getParameter("id");
		noteService.delete(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('成功删除留言');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/note/index.jsp");*/
	}

	private void alist(HttpServletRequest request, HttpServletResponse response, NoteService noteService)  throws ServletException, IOException{
		System.out.println("进入显示所有留言操作");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String pageNoStr = request.getParameter("pageNo");
		Map<String, Object> map=noteService.getrAll(pageNoStr);
		List<Note> nList=(List<Note>) map.get("nList");
		PageUtil pu=(PageUtil) map.get("pu");
		StringBuffer buf=new StringBuffer();
		//{"pu":{"pageCount":?,"pageSize":?,"pageNo":?,"total":?},"nList":[{"name":"?","content":"?","review":"?","id":?},{},{}]}
		buf.append("{\"pu\":{\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"pageNo\":"+pu.getPageNo()+",\"total\":"+pu.getTotal()+"},\"nList\":[");
		for(int i=0;i<nList.size();i++){
			Note n=nList.get(i);
			//buf.append("{\"name\":\""+n.getName()+"\",\"content\":\""+n.getContent()+"\",\"review\":\""+n.getReview()+"\",\"id\":"+n.getId()+"}");
			buf.append("{\"name\":\"");
			buf.append(n.getName());
			buf.append("\",\"content\":\"");
			buf.append(n.getContent());
			buf.append("\",\"review\":\"");
			buf.append(n.getReview());
			buf.append("\",\"id\":");
			buf.append(n.getId());
			buf.append("}");
			if(i<nList.size()-1){
				buf.append(",");
			}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}

	private void list(HttpServletRequest request, HttpServletResponse response, NoteService noteService)  throws ServletException, IOException{
		System.out.println("进入已通过审核留言列表显示操作");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String pageNoStr = request.getParameter("pageNo");
		Map<String, Object> map=noteService.getAll(pageNoStr);
		List<Note> nList=(List<Note>) map.get("nList");
		PageUtil pu=(PageUtil) map.get("pu");
		StringBuffer buf=new StringBuffer();
		//{"pu":{"pageCount":?,"pageSize":?,"pageNo":?,"total":?},"nList":[{"name":"?","content":"?","review":"?","id":?},{},{}]}
		buf.append("{\"pu\":{\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"pageNo\":"+pu.getPageNo()+",\"total\":"+pu.getTotal()+"},\"nList\":[");
		for(int i=0;i<nList.size();i++){
			Note n=nList.get(i);
			//buf.append("{\"name\":\""+n.getName()+"\",\"content\":\""+n.getContent()+"\",\"review\":\""+n.getReview()+"\",\"id\":"+n.getId()+"}");
			buf.append("{\"name\":\"");
			buf.append(n.getName());
			buf.append("\",\"content\":\"");
			buf.append(n.getContent());
			buf.append("\",\"review\":\"");
			buf.append(n.getReview());
			buf.append("\",\"id\":");
			buf.append(n.getId());
			buf.append("}");
			if(i<nList.size()-1){
				buf.append(",");
			}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
		
		
	}

	private void add(HttpServletRequest request, HttpServletResponse response, NoteService noteService) throws ServletException, IOException {
		System.out.println("进入留言添加操作");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String name=request.getParameter("name");
		String content=request.getParameter("content");
		String tnote="教师暂未回复";
		System.out.println(name);
		System.out.println(content);
		Note n=new  Note();
		n.setName(name);
		n.setContent(content);
		n.setTnote(tnote);
		noteService.add(n);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('留言添加成功，请等待管理员审核');history.go(-2);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/note.jsp");*/
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doGet(request, response);
	}

}
