package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.domain.Student;
import com.domain.Teacher;
import com.service.StudentService;
import com.service.TeacherService;
import com.service.impl.AdminServiceImpl;
import com.service.impl.StudentServiceImpl;
import com.service.impl.TeacherServiceImpl;
import com.util.PageUtil;
import com.util.ServiceFactory;

public class TeacherController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("进入教师信息管理模块");
		TeacherService teacherService=(TeacherService) ServiceFactory.getService(new TeacherServiceImpl());
		String servletPath = request.getServletPath();
		if (servletPath.equals("/teacher/list.do")) {
			
			list(request,response,teacherService);
			
		} else if(servletPath.equals("/teacher/save.do")) {
			
			save(request,response,teacherService);
			
		}else if(servletPath.equals("/teacher/edit.do")) {
			
			edit(request,response,teacherService);
			
		}else if(servletPath.equals("/teacher/update.do")) {
			
			update(request,response,teacherService);
			
		}else if(servletPath.equals("/teacher/delete.do")) {
			
			delete(request,response,teacherService);
			
		}else if(servletPath.equals("/teacher/getUserId.do")) {
			
			getuserid(request,response,teacherService);
			
		}else if(servletPath.equals("/teacher/pass.do")) {
			
			pass(request,response,teacherService);
			
		}else if(servletPath.equals("/teacher/listp.do")) {
			
			listp(request,response,teacherService);
			
		}else if(servletPath.equals("/teacher/pwd.do")) {
			
			pwd(request,response,teacherService);
			
		}
	}

	
	private void pwd(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService)  throws ServletException, IOException{
		System.out.println("进入教师修改密码操作");
		HttpSession session = request.getSession();
		String tid = (String)session.getAttribute("teacher");
		String opassword = request.getParameter("opassword");
		String npassword = request.getParameter("npassword");
		Teacher t=new Teacher();
		System.out.println(tid);
		String opassword1=teacherService.getpassword(tid);
		System.out.println(opassword);
		if(opassword.equals(opassword1)){
			t.setId(tid);
			t.setPassword(npassword);
			teacherService.pwd(t);
			PrintWriter out = response.getWriter();
			out.print("<script>alert('密码修改成功');history.go(-2);</script>");
			out.close();
			/*response.sendRedirect(request.getContextPath()+"/jsp/teachersc/index.jsp");*/
		}else{
			response.sendRedirect(request.getContextPath()+"/jsp/teachersc/error.html");
		}
		
		
	}


	private void listp(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService)  throws ServletException, IOException{
		System.out.println("进入显示未审核学生列表操作");
		List<Teacher> tList=teacherService.listp();
		//{"sList":[{"id":"?","name":"?","age":?},{},{}]}
		StringBuffer buf=new StringBuffer();
		buf.append("{\"tList\":[");
		for(int i=0;i<tList.size();i++){
			Teacher t=tList.get(i);
		//buf.append("{\"id\":\""+t.getId()+"\",\"name\":\""+t.getName()+"\",\"age\":"+t.getAge()+",\"review\":\""+t.getReview()+"\",\"department\":\""+t.getDepartment()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(t.getId());
		buf.append("\",\"name\":\"");
		buf.append(t.getName());
		buf.append("\",\"age\":");
		buf.append(t.getAge());
		buf.append(",\"review\":\"");
		buf.append(t.getReview());
		buf.append("\",\"department\":\"");
		buf.append(t.getDepartment());
		buf.append("\"}");
		if(i<tList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}


	private void pass(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService) throws ServletException, IOException {
		System.out.println("进入教师审核通过操作");
		String id = request.getParameter("id");
		System.out.println(id);
		teacherService.pass(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('审核成功');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/teacher/check.jsp");*/
		
	}


	private void getuserid(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService) throws ServletException, IOException{
		System.out.println("进入获得教师id操作");
		String id=teacherService.getuserid();
		System.out.println(id);
		PrintWriter out= response.getWriter();
		out.print(id);
		out.close();
	}


	private void delete(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService)throws ServletException, IOException {
		
		System.out.println("进入教师删除操作");
		String id[]=request.getParameterValues("id");
		teacherService.delete(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('教师删除成功');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/teacher/index.jsp");*/
		
	}


	private void update(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService)throws ServletException, IOException {
		
		System.out.println("进入教师信息更新操作");
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String agestr=request.getParameter("age");
		String department=request.getParameter("department");
		int age=Integer.valueOf(agestr);
		Teacher t=new Teacher();
		t.setId(id);
		t.setAge(age);
		t.setName(name);
		t.setDepartment(department);
		teacherService.update(t);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('信息更新成功');history.go(-2);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/teacher/index.jsp");*/
		
	}


	private void edit(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService)throws ServletException, IOException {
		
		System.out.println("进入根据id查询单条操作");
		String id=request.getParameter("id");
		Teacher t=teacherService.edit(id);
		String string="{\"id\":\""+t.getId()+"\",\"name\":\""+t.getName()+"\",\"age\":"+t.getAge()+",\"department\":\""+t.getDepartment()+"\"}";
		System.out.println(string);
		PrintWriter out = response.getWriter();
		out.print(string);
		out.close();
		
	}


	private void save(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService)throws ServletException, IOException {
		System.out.println("进入添加操作");
		String name = request.getParameter("name");
		String agestr = request.getParameter("age");
		String sex = request.getParameter("sex");
		String department=request.getParameter("department");
		int age=Integer.valueOf(agestr);
		Teacher t=new Teacher();
		t.setName(name);
		t.setAge(age);
		t.setSex(sex);
		t.setDepartment(department);
		teacherService.add(t);
		response.sendRedirect(request.getContextPath()+"/jsp/teacher/index.jsp");
		
	}


	private void list(HttpServletRequest request, HttpServletResponse response, TeacherService teacherService)throws ServletException, IOException {
		
		System.out.println("进入查询列表操作");
		String pageNoStr = request.getParameter("pageNo");
		
		Map<String, Object> map=teacherService.getAll(pageNoStr);
		List<Teacher> tList=(List<Teacher>) map.get("tList");
		PageUtil pu=(PageUtil) map.get("pu");
		//{"tList":[{"id":"?","name":"?","age":?},{},{}]}
		//{"pu":{"pageNo":?,"pageCount":?,"pageSize":?,"total":?},"sList":[{"id":"?","name":"?","age":?},{},{}]}
		StringBuffer buf=new StringBuffer();
		buf.append("{\"pu\":{\"pageNo\":"+pu.getPageNo()+",\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"total\":"+pu.getTotal()+"},\"tList\":[");
		
		for(int i=0;i<tList.size();i++){
			Teacher t=tList.get(i);
		//buf.append("{\"id\":\""+t.getId()+"\",\"name\":\""+t.getName()+"\",\"age\":"+t.getAge()+",\"review\":\""+t.getReview()+"\",\"department\":\""+t.getDepartment()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(t.getId());
		buf.append("\",\"name\":\"");
		buf.append(t.getName());
		buf.append("\",\"age\":");
		buf.append(t.getAge());
		buf.append(",\"review\":\"");
		buf.append(t.getReview());
		buf.append("\",\"department\":\"");
		buf.append(t.getDepartment());
		buf.append("\"}");
		if(i<tList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doGet(request, response);
	}

}
