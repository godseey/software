package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.bcel.internal.generic.GOTO;

public class LogoutController extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("退出登录操作");
		String servletPath  = request.getServletPath();
		if (servletPath.equals("/student/logout.do")) {
			
			request.getSession().removeAttribute("student");
			request.getSession().invalidate();
			Cookie[] cookies=request.getCookies();
			for (Cookie cookie : cookies) {
					cookie.setMaxAge(0);
					cookie.setPath("/");
					response.addCookie(cookie);
			}
			response.sendRedirect(request.getContextPath()+"/index.jsp");
					
		}else if(servletPath.equals("/teacher/logout.do")) {
			
			request.getSession().removeAttribute("teacher");
			request.getSession().invalidate();
			Cookie[] cookies=request.getCookies();
			for (Cookie cookie : cookies) {
					cookie.setMaxAge(0);
					cookie.setPath("/");
					response.addCookie(cookie);
			}
			response.sendRedirect(request.getContextPath()+"/index.jsp");
					
		} else if(servletPath.equals("/manager/logout.do")) {
			
			request.getSession().removeAttribute("admin");
			request.getSession().invalidate();
			Cookie[] cookies=request.getCookies();
			for (Cookie cookie : cookies) {
					cookie.setMaxAge(0);
					cookie.setPath("/");
					response.addCookie(cookie);
			}
			response.sendRedirect(request.getContextPath()+"/index.jsp");
					
		} 
		
		
		
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}
}
