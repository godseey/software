package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.domain.Student;
import com.service.StudentService;
import com.service.impl.AdminServiceImpl;
import com.service.impl.StudentServiceImpl;
import com.util.PageUtil;
import com.util.ServiceFactory;

public class StudentController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("进入学生信息管理模块");
		StudentService studentService=(StudentService) ServiceFactory.getService(new StudentServiceImpl());
		String servletPath = request.getServletPath();
		if (servletPath.equals("/student/list.do")) {
			
			list(request,response,studentService);
			
		} else if(servletPath.equals("/student/save.do")) {
			
			save(request,response,studentService);
			
		}else if(servletPath.equals("/student/edit.do")) {
			
			edit(request,response,studentService);
			
		}else if(servletPath.equals("/student/update.do")) {
			
			update(request,response,studentService);
			
		}else if(servletPath.equals("/student/delete.do")) {
			
			delete(request,response,studentService);
			
		}else if(servletPath.equals("/student/getUserId.do")) {
			
			getuserid(request,response,studentService);
			
		}else if(servletPath.equals("/student/pass.do")) {
			
			pass(request,response,studentService);
			
		}else if(servletPath.equals("/student/listp.do")) {
			
			listp(request,response,studentService);
			
		}else if(servletPath.equals("/student/sc.do")) {
			
			sc(request,response,studentService);
			
		}else if(servletPath.equals("/student/scl.do")) {
			
			scl(request,response,studentService);
			
		}else if(servletPath.equals("/student/dscl.do")) {
			
			dscl(request,response,studentService);
			
		}
		
	}




	private void dscl(HttpServletRequest request, HttpServletResponse response, StudentService studentService) throws ServletException, IOException{
		System.out.println("指定课程移除学生删除操作");
		String id=request.getParameter("id");
		String cid=request.getParameter("cid");
		/*System.out.println(id);
		System.out.println(cid);*/
		studentService.dscl(id,cid);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('学生删除成功');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/teachersc/scl.jsp?id="+cid+"");*/
		
	}




	private void scl(HttpServletRequest request, HttpServletResponse response, StudentService studentService) throws ServletException, IOException{
		System.out.println("进入根据课程名查询所选学生列表操作");
		String id = request.getParameter("cid");
		List<Student> sList=studentService.scl(id);
		//{"sList":[{"id":"?","name":"?","age":?,"department":"?","sex":"?"},{},{}]}
		StringBuffer buf=new StringBuffer();
		buf.append("{\"sList\":[");
		for(int i=0;i<sList.size();i++){
			Student s=sList.get(i);
		//buf.append("{\"id\":\""+s.getId()+"\",\"name\":\""+s.getName()+"\",\"age\":"+s.getAge()+",\"sex\":\""+s.getSex()+"\",\"department\":\""+s.getDepartment()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(s.getId());
		buf.append("\",\"name\":\"");
		buf.append(s.getName());
		buf.append("\",\"age\":");
		buf.append(s.getAge());
		buf.append(",\"sex\":\"");
		buf.append(s.getSex());
		buf.append("\",\"department\":\"");
		buf.append(s.getDepartment());
		buf.append("\"}");
		if(i<sList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
		
	}




	private void sc(HttpServletRequest request, HttpServletResponse response, StudentService studentService)throws ServletException, IOException {
		System.out.println("学生选课操作");
		HttpSession session = request.getSession();
		String sid = (String)session.getAttribute("student");
		System.out.println(sid);
		String cid = request.getParameter("id");
		System.out.println(cid);
		studentService.sc(sid,cid);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('选修课程成功');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/studentsc/sc.jsp");*/
		
	}




	private void listp(HttpServletRequest request, HttpServletResponse response, StudentService studentService)  throws ServletException, IOException{
		System.out.println("进入显示未审核学生列表操作");
		List<Student> sList=studentService.listp();
		//{"sList":[{"id":"?","name":"?","age":?},{},{}]}
		StringBuffer buf=new StringBuffer();
		buf.append("{\"sList\":[");
		for(int i=0;i<sList.size();i++){
			Student s=sList.get(i);
		//buf.append("{\"id\":\""+s.getId()+"\",\"name\":\""+s.getName()+"\",\"age\":"+s.getAge()+",\"review\":\""+s.getReview()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(s.getId());
		buf.append("\",\"name\":\"");
		buf.append(s.getName());
		buf.append("\",\"age\":");
		buf.append(s.getAge());
		buf.append(",\"review\":\"");
		buf.append(s.getReview());
		buf.append("\"}");
		if(i<sList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}


	private void pass(HttpServletRequest request, HttpServletResponse response, StudentService studentService) throws ServletException, IOException {
		System.out.println("进入学生审核通过操作");
		String id = request.getParameter("id");
		System.out.println(id);
		studentService.pass(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('学生审核成功');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/student/check.jsp");*/
		
	}


	private void getuserid(HttpServletRequest request, HttpServletResponse response, StudentService studentService) throws ServletException, IOException{
		System.out.println("进入获得id操作");
		String id=studentService.getuserid();
		System.out.println(id);
		PrintWriter out= response.getWriter();
		out.print(id);
		out.close();
	}


	private void delete(HttpServletRequest request, HttpServletResponse response, StudentService studentService)throws ServletException, IOException {
		
		System.out.println("进入学生删除操作");
		String id[]=request.getParameterValues("id");
		studentService.delete(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('成功删除学生');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/student/index.jsp");*/
		
	}


	private void update(HttpServletRequest request, HttpServletResponse response, StudentService studentService)throws ServletException, IOException {
		
		System.out.println("进入学生信息更新操作");
		String servletPath = request.getServletPath();
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String agestr=request.getParameter("age");
		String sex=request.getParameter("sex");
		String password=request.getParameter("npassword");
		String opassword1=request.getParameter("opassword");
		String department=request.getParameter("department");
		String idc=request.getParameter("idc");
		if(password==null){
			int age=Integer.valueOf(agestr);
			Student s=new Student();
			s.setId(id);
			s.setAge(age);
			s.setName(name);
			s.setDepartment(department);
			s.setIdc(idc);
			s.setSex(sex);
			System.out.println(s.getSex());
			studentService.update(s);
			if (servletPath.equals("/student/update.do")) {
				PrintWriter out = response.getWriter();
				out.print("<script>alert('资料修改成功');history.go(-2);</script>");
				out.close();
				/*response.sendRedirect(request.getContextPath()+"/jsp/student/index.jsp");*/
				
			} else{
				
				
				
			}
			
		}else{
			Student s=new Student();
			System.out.println(id);
			String opassword=studentService.getpassword(id);
			System.out.println(opassword);
			if(opassword.equals(opassword1)){
				s.setId(id);
				s.setPassword(password);
				studentService.update(s);
				PrintWriter out = response.getWriter();
				out.print("<script>alert('密码修改成功');history.go(-2);</script>");
				out.close();
				/*response.sendRedirect(request.getContextPath()+"/jsp/studentsc/index.jsp");*/
			}else{
				response.sendRedirect(request.getContextPath()+"/jsp/studentsc/error.html");
			}

		}
		

		
		
		
		
	}


	private void edit(HttpServletRequest request, HttpServletResponse response, StudentService studentService)throws ServletException, IOException {
		
		System.out.println("进入根据id查询单条操作");
		String id=request.getParameter("id");
		Student s=studentService.edit(id);
		String string="{\"id\":\""+s.getId()+"\",\"name\":\""+s.getName()+"\",\"age\":"+s.getAge()+",\"sex\":\""+s.getSex()+"\",\"department\":\""+s.getDepartment()+"\",\"idc\":\""+s.getIdc()+"\",\"ptype\":"+s.getPtype()+",\"password\":\""+s.getPassword()+"\"}";
		System.out.println(string);
		PrintWriter out = response.getWriter();
		out.print(string);
		out.close();
		
	}


	private void save(HttpServletRequest request, HttpServletResponse response, StudentService studentService)throws ServletException, IOException {
		System.out.println("进入添加操作");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String agestr = request.getParameter("age");
		String sex = request.getParameter("sex");
		int age=Integer.valueOf(agestr);
		Student s=new  Student();
		s.setName(name);
		s.setAge(age);
		s.setSex(sex);
		s.setId(id);
		studentService.add(s);
		response.sendRedirect(request.getContextPath()+"/jsp/student/index.jsp");
		
	}


	private void list(HttpServletRequest request, HttpServletResponse response, StudentService studentService)throws ServletException, IOException {
		
		System.out.println("进入查询列表操作");
		String pageNoStr = request.getParameter("pageNo");
		
		Map<String, Object> map=studentService.getAll(pageNoStr);
		List<Student> sList=(List<Student>) map.get("sList");
		PageUtil pu=(PageUtil) map.get("pu");
		//{"sList":[{"id":"?","name":"?","age":?},{},{}]}
		//{"pu":{"pageNo":?,"pageCount":?,"pageSize":?,"total":?},"sList":[{"id":"?","name":"?","age":?},{},{}]}
		StringBuffer buf=new StringBuffer();
		buf.append("{\"pu\":{\"pageNo\":"+pu.getPageNo()+",\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"total\":"+pu.getTotal()+"},\"sList\":[");
		
		for(int i=0;i<sList.size();i++){
			Student s=sList.get(i);
		//buf.append("{\"id\":\""+s.getId()+"\",\"name\":\""+s.getName()+"\",\"age\":"+s.getAge()+",\"review\":\""+s.getReview()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(s.getId());
		buf.append("\",\"name\":\"");
		buf.append(s.getName());
		buf.append("\",\"age\":");
		buf.append(s.getAge());
		buf.append(",\"review\":\"");
		buf.append(s.getReview());
		buf.append("\"}");
		if(i<sList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doGet(request, response);
	}

}
