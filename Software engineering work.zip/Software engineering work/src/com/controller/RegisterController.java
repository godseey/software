package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.domain.Student;
import com.domain.Teacher;
import com.service.PaperService;
import com.service.StudentService;
import com.service.TeacherService;
import com.service.impl.PaperServiceImpl;
import com.service.impl.StudentServiceImpl;
import com.service.impl.TeacherServiceImpl;
import com.sun.org.apache.bcel.internal.generic.GOTO;
import com.util.ServiceFactory;

public class RegisterController extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("进入用户注册模块");
		String servletPath  = request.getServletPath();
		StudentService studentService=(StudentService) ServiceFactory.getService(new StudentServiceImpl());
		TeacherService teacherService=(TeacherService) ServiceFactory.getService(new TeacherServiceImpl());
		
		if (servletPath.equals("/register.do")) {
			
			list(request,response,studentService,teacherService);
			
		} 
	}
	
	private void list(HttpServletRequest request, HttpServletResponse response, StudentService studentService,TeacherService teacherService) throws ServletException, IOException {
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String idc = request.getParameter("idc");
		String name = request.getParameter("rname");
		String type=request.getParameter("type");
		/*System.out.println(type);
		System.out.println(id);
		System.out.println(pwd);
		System.out.println(name);
		System.out.println(idc);*/
		if(type.equals("student")){
			/*System.out.println("success");*/
			boolean flag=studentService.seach(id);
			if(flag){
				Student s=new Student();
				s.setId(id);
				s.setName(name);
				s.setPassword(pwd);
				s.setIdc(idc);
				studentService.register(s);
				response.sendRedirect(request.getContextPath()+"/success.html");
			}else{
				PrintWriter out = response.getWriter();
				out.print("<script>alert('该学生账户已存在，请返回重新输入');history.go(-1);</script>");
				out.close();
			}
			
		}else{
			boolean flag=teacherService.seach(id);
			if(flag){
				Teacher t=new Teacher();
				t.setId(id);
				t.setName(name);
				t.setPassword(pwd);
				t.setIdc(idc);
				teacherService.register(t);
				response.sendRedirect(request.getContextPath()+"/success.html");
			}else {
				PrintWriter out = response.getWriter();
				out.print("<script>alert('该教师账户已存在，请返回重新输入');history.go(-1);</script>");
				out.close();
			}
			
		}
		
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}
}
