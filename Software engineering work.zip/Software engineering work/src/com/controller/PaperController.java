package com.controller;

import java.awt.print.Paper;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;

import com.domain.Note;
import com.domain.Papern;
import com.domain.Student;
import com.service.PaperService;
import com.service.impl.PaperServiceImpl;
import com.util.DButil;
import com.util.PageUtil;
import com.util.ServiceFactory;

import javafx.css.PseudoClass;

public class PaperController extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("进入文章信息管理模块");
		PaperService paperService=(PaperService) ServiceFactory.getService(new PaperServiceImpl());
		String servletPath  = request.getServletPath();
		if (servletPath.equals("/paper/list.do")) {
			
			list(request,response,paperService);
			
		} else if(servletPath.equals("/paper/save.do")) {
			
			save(request,response,paperService);
			
		}else if(servletPath.equals("/paper/listp.do")) {
			
			listp(request,response,paperService);
			
		}else if(servletPath.equals("/paper/pass.do")) {
			
			pass(request,response,paperService);
			
		}else if(servletPath.equals("/paper/update.do")) {
			
			update(request,response,paperService);
			
		}else if(servletPath.equals("/paper/delete.do")) {
			
			delete(request,response,paperService);
			
		}else if(servletPath.equals("/paper/dlist.do")) {
			
			dlist(request,response,paperService);
			
		}else if(servletPath.equals("/paper/plist.do")) {
			
			plist(request,response,paperService);
			
		}else if(servletPath.equals("/paper/tsave.do")) {
			
			tsave(request,response,paperService);
			 
		}else if(servletPath.equals("/paper/nlist.do")) {
			
			nlist(request,response,paperService);
			 
		}else if(servletPath.equals("/paper/palist.do")) {
			
			palist(request,response,paperService);
			 
		}else if(servletPath.equals("/paper/edita.do")) {
			
			edita(request,response,paperService);
			 
		} 
		
	}
	
	private void edita(HttpServletRequest request, HttpServletResponse response, PaperService paperService)throws ServletException, IOException {
		System.out.println("进入文章显示所有内容展示操作");
		String pid=request.getParameter("id");
		Papern p=paperService.edita(pid);
		StringBuffer buf=new StringBuffer();
		//buf.append("{\"content\":\""+p.getContent()+"\",\"title\":\""+p.getTitle()+"\",\"author\":\""+p.getAuthor()+"\",\"cif\":\""+p.getCif()+"\",\"descc\":\""+p.getDesc()+"\"}");
		buf.append("{\"id\":\"");
		buf.append(pid);
		buf.append("\",\"title\":\"");
		buf.append(p.getTitle());
		buf.append("\",\"author\":\"");
		buf.append(p.getAuthor());
		buf.append("\",\"cif\":\"");
		buf.append(p.getCif());
		buf.append("\",\"content\":\"");
		buf.append(p.getContent());
		buf.append("\",\"desc\":\"");
		buf.append(p.getDesc());
		buf.append("\"}");
		System.out.println(buf);
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}

	private void palist(HttpServletRequest request, HttpServletResponse response, PaperService paperService)throws ServletException, IOException {
		System.out.println("进入前台显示国防文章通过缩略显示操作");
		String pageNoStr = request.getParameter("pageNo");
		Map<String, Object> map=paperService.getpdesc(pageNoStr);
		List<Papern> pList=(List<Papern>) map.get("pList");
		PageUtil pu=(PageUtil) map.get("pu");
		StringBuffer buf=new StringBuffer();
		//{"dList":[{"id":"?","title":"?","author":"?","cif":"?","desc":"?"},{},{}]}
		buf.append("{\"pu\":{\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"pageNo\":"+pu.getPageNo()+",\"total\":"+pu.getTotal()+"},\"pList\":[");
		for(int i=0;i<pList.size();i++){
			Papern p=pList.get(i);
		//buf.append("{\"id\":\""+p.getId()+"\",\"title\":\""+p.getTitle()+"\",\"author\":\""+p.getAuthor()+"\",\"cif\":\""+p.getCif()+"\",\"desc\":\""+p.getDesc()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(p.getId());
		buf.append("\",\"title\":\"");
		buf.append(p.getTitle());
		buf.append("\",\"author\":\"");
		buf.append(p.getAuthor());
		buf.append("\",\"cif\":\"");
		buf.append(p.getCif());
		buf.append("\",\"desc\":\"");
		buf.append(p.getDesc());
		buf.append("\"}");
		if(i<pList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}

	private void nlist(HttpServletRequest request, HttpServletResponse response, PaperService paperService)throws ServletException, IOException {
		System.out.println("进入前台显示新闻文章通过缩略显示操作");
		String pageNoStr = request.getParameter("pageNo");
		Map<String, Object> map=paperService.getndesc(pageNoStr);
		List<Papern> nList=(List<Papern>) map.get("nList");
		PageUtil pu=(PageUtil) map.get("pu");
		StringBuffer buf=new StringBuffer();
		//{"dList":[{"id":"?","title":"?","author":"?","cif":"?","desc":"?"},{},{}]}
		buf.append("{\"pu\":{\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"pageNo\":"+pu.getPageNo()+",\"total\":"+pu.getTotal()+"},\"nList\":[");
		for(int i=0;i<nList.size();i++){
			Papern n=nList.get(i);
		//buf.append("{\"id\":\""+n.getId()+"\",\"title\":\""+n.getTitle()+"\",\"author\":\""+n.getAuthor()+"\",\"cif\":\""+n.getCif()+"\",\"desc\":\""+n.getDesc()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(n.getId());
		buf.append("\",\"title\":\"");
		buf.append(n.getTitle());
		buf.append("\",\"author\":\"");
		buf.append(n.getAuthor());
		buf.append("\",\"cif\":\"");
		buf.append(n.getCif());
		buf.append("\",\"desc\":\"");
		buf.append(n.getDesc());
		buf.append("\"}");
		if(i<nList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}

	private void tsave(HttpServletRequest request, HttpServletResponse response, PaperService paperService)throws ServletException, IOException {
		System.out.println("进入教师文章添加操作");
		String author = request.getParameter("author");
		String cif = request.getParameter("cif");
		String title = request.getParameter("title");
		String descc=request.getParameter("descc");
		String econtent = request.getParameter("content");
		HttpSession session = request.getSession();
		String tid = (String)session.getAttribute("teacher");
		final Base64 base64 = new Base64();
		final String text = econtent;
		final byte[] textByte = text.getBytes("UTF-8");
		//編碼
		final String content = base64.encodeToString(textByte);
		/*System.out.println(author);
		System.out.println(cif);
		System.out.println(title);
		System.out.println(content);*/
		Papern p=new  Papern();
		p.setAuthor(author);
		p.setCif(cif);
		p.setContent(content);
		p.setDesc(descc);
		p.setTitle(title);
		p.setTeacher(tid);
		paperService.save(p);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('文章发布成功');history.go(-2);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/teachersc/paper.jsp");*/
	}


	private void plist(HttpServletRequest request, HttpServletResponse response, PaperService paperService) throws ServletException, IOException{
		System.out.println("进入后台显示已审核通过文章列表显示操作");
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("teacher");
		System.out.println(id);
		String pageNoStr = request.getParameter("pageNo");
		Map<String, Object> map=paperService.getplist(pageNoStr,id);
		List<Papern> pList=(List<Papern>) map.get("pList");
		PageUtil pu=(PageUtil) map.get("pu");
		//{"pu":{"pageCount":?,"pageSize":?,"pageNo":?,"total":?},"pList":[{"id":"?","title":"?","author":"?","cif":"?"},{},{}]}
		StringBuffer buf=new StringBuffer();
		buf.append("{\"pu\":{\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"pageNo\":"+pu.getPageNo()+",\"total\":"+pu.getTotal()+"},\"pList\":[");;
		for(int i=0;i<pList.size();i++){
			Papern p=pList.get(i);
		//buf.append("{\"id\":\""+p.getId()+"\",\"title\":\""+p.getTitle()+"\",\"review\":\""+p.getReview()+"\",\"teacher\":\""+p.getTeacher()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(p.getId());
		buf.append("\",\"title\":\"");
		buf.append(p.getTitle());
		buf.append("\",\"review\":\"");
		buf.append(p.getReview());
		buf.append("\",\"teacher\":\"");
		buf.append(p.getTeacher());
		buf.append("\"}");
		if(i<pList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
		
	}

	private void dlist(HttpServletRequest request, HttpServletResponse response, PaperService paperService) throws ServletException, IOException{
		System.out.println("进入前台主页显示所有文章通过缩略显示操作");
		String pageNoStr = request.getParameter("pageNo");
		Map<String, Object> map=paperService.getdesc(pageNoStr);
		List<Papern> pList=(List<Papern>) map.get("pList");
		PageUtil pu=(PageUtil) map.get("pu");
		StringBuffer buf=new StringBuffer();
		//{"dList":[{"id":"?","title":"?","author":"?","cif":"?","desc":"?"},{},{}]}
		buf.append("{\"pu\":{\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"pageNo\":"+pu.getPageNo()+",\"total\":"+pu.getTotal()+"},\"pList\":[");
		for(int i=0;i<pList.size();i++){
			Papern p=pList.get(i);
		//buf.append("{\"id\":\""+p.getId()+"\",\"title\":\""+p.getTitle()+"\",\"author\":\""+p.getAuthor()+"\",\"cif\":\""+p.getCif()+"\",\"desc\":\""+p.getDesc()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(p.getId());
		buf.append("\",\"title\":\"");
		buf.append(p.getTitle());
		buf.append("\",\"author\":\"");
		buf.append(p.getAuthor());
		buf.append("\",\"cif\":\"");
		buf.append(p.getCif());
		buf.append("\",\"desc\":\"");
		buf.append(p.getDesc());
		buf.append("\"}");
		if(i<pList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
		
	}

	private void delete(HttpServletRequest request, HttpServletResponse response, PaperService paperService)throws ServletException, IOException {
		HttpSession session = request.getSession();
		String tid = (String)session.getAttribute("teacher");
		String aid = (String)session.getAttribute("admin");
		/*System.out.println(tid);
		System.out.println(aid);*/
		System.out.println("进入文章删除操作");
		String id[]=request.getParameterValues("id");
		paperService.delete(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('文章删除成功');history.go(-1);</script>");
		out.close();
		/*if(tid==null){
			response.sendRedirect(request.getContextPath()+"/jsp/paper/index.jsp");
		}else{
			response.sendRedirect(request.getContextPath()+"/jsp/teachersc/paper.jsp");
		}*/
	}

	private void update(HttpServletRequest request, HttpServletResponse response, PaperService paperService)throws ServletException, IOException {
		System.out.println("进入文章信息更新操作");
		String id=request.getParameter("cid");
		System.out.println(id);
		String title=request.getParameter("title");
		String author=request.getParameter("author");
		String cif=request.getParameter("cif");
		String descp=request.getParameter("descc");
		String econtent=request.getParameter("content");
		final Base64 base64 = new Base64();
		final String text = econtent;
		final byte[] textByte = text.getBytes("UTF-8");
		//編碼
		final String content = base64.encodeToString(textByte);
		Papern p=new Papern();
		p.setAuthor(author);
		p.setId(id);
		p.setCif(cif);
		p.setContent(content);
		p.setTitle(title);
		p.setDesc(descp);
		paperService.update(p);
		paperService.rcheck(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('文章修改成功');history.go(-2);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/paper/index.jsp");*/
		
	}

	private void pass(HttpServletRequest request, HttpServletResponse response, PaperService paperService) throws ServletException, IOException{
		System.out.println("进入文章审核通过操作");
		String id = request.getParameter("id");
		System.out.println(id);
		paperService.pass(id);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('文章审核成功');history.go(-1);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/paper/check.jsp");*/
	
		
		
	}

	private void listp(HttpServletRequest request, HttpServletResponse response, PaperService paperService)throws ServletException, IOException {
		System.out.println("进入未审核文章显示操作");
		List<Papern> pList=paperService.review();
		//{"pList":[{"id":"?","title":"?","author":"?","cif":"?"},{},{}]}
		StringBuffer buf=new StringBuffer();
		buf.append("{\"pList\":[");
		for(int i=0;i<pList.size();i++){
			Papern p=pList.get(i);
		//buf.append("{\"id\":\""+p.getId()+"\",\"title\":\""+p.getTitle()+"\",\"author\":\""+p.getAuthor()+"\",\"cif\":\""+p.getCif()+"\",\"review\":\""+p.getReview()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(p.getId());
		buf.append("\",\"title\":\"");
		buf.append(p.getTitle());
		buf.append("\",\"author\":\"");
		buf.append(p.getAuthor());
		buf.append("\",\"cif\":\"");
		buf.append(p.getCif());
		buf.append("\",\"review\":\"");
		buf.append(p.getReview());
		buf.append("\"}");
		if(i<pList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
		
	}

	private void list(HttpServletRequest request, HttpServletResponse response, PaperService paperService) throws ServletException, IOException{
		System.out.println("进入文章列表显示操作");
		String pageNoStr = request.getParameter("pageNo");
		Map<String, Object> map=paperService.getAll(pageNoStr);
	
		List<Papern> pList=(List<Papern>) map.get("pList");
		PageUtil pu=(PageUtil) map.get("pu");
		
		
		//{"pu":{"pageCount":?,"pageSize":?,"pageNo":?,"total":?},"pList":[{"id":"?","title":"?","author":"?","cif":"?"},{},{}]}
		StringBuffer buf=new StringBuffer();
		buf.append("{\"pu\":{\"pageCount\":"+pu.getPageCount()+",\"pageSize\":"+pu.getPageSize()+",\"pageNo\":"+pu.getPageNo()+",\"total\":"+pu.getTotal()+"},\"pList\":[");;
		for(int i=0;i<pList.size();i++){
			Papern p=pList.get(i);
		//buf.append("{\"id\":\""+p.getId()+"\",\"title\":\""+p.getTitle()+"\",\"author\":\""+p.getAuthor()+"\",\"cif\":\""+p.getCif()+"\"}");	
		buf.append("{\"id\":\"");
		buf.append(p.getId());
		buf.append("\",\"title\":\"");
		buf.append(p.getTitle());
		buf.append("\",\"author\":\"");
		buf.append(p.getAuthor());
		buf.append("\",\"cif\":\"");
		buf.append(p.getCif());
		buf.append("\",\"review\":\"");
		buf.append(p.getReview());
		buf.append("\"}");
		if(i<pList.size()-1){
			buf.append(",");
		}
		}
		buf.append("]}");
		System.out.println(buf.toString());
		PrintWriter out = response.getWriter();
		out.print(buf.toString());
		out.close();
	}

	private void save(HttpServletRequest request, HttpServletResponse response, PaperService paperService)throws ServletException, IOException {
		System.out.println("进入管理员文章添加操作");
		String author = request.getParameter("author");
		String cif = request.getParameter("cif");
		String title = request.getParameter("title");
		String econtent = request.getParameter("content");
		String descc=request.getParameter("descc");
		String id=request.getParameter("tid");
		final Base64 base64 = new Base64();
		final String text = econtent;
		final byte[] textByte = text.getBytes("UTF-8");
		//編碼
		final String content = base64.encodeToString(textByte);
		/*System.out.println(author);
		System.out.println(cif);
		System.out.println(title);
		System.out.println(content);*/
		Papern p=new  Papern();
		p.setAuthor(author);
		p.setCif(cif);
		p.setContent(content);
		p.setTitle(title);
		p.setDesc(descc);
		p.setTeacher(id);
		paperService.save(p);
		PrintWriter out = response.getWriter();
		out.print("<script>alert('文章发布成功');history.go(-2);</script>");
		out.close();
		/*response.sendRedirect(request.getContextPath()+"/jsp/paper/index.jsp");*/
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		this.doGet(request,response);
	}
}
